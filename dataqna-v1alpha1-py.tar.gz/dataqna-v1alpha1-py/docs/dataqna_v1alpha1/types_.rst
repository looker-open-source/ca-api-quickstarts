Types for Google Cloud Dataqna v1alpha1 API
===========================================

.. automodule:: google.cloud.dataqna_v1alpha1.types
    :members:
    :show-inheritance:
